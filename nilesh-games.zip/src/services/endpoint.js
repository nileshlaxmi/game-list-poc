export default {
  getGameData: () => `http://starlord.hackerearth.com/gamesext`,
};
